/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/SessionLocal.java to edit this template
 */
package ejb;

import javax.ejb.Local;
import entity.Mydata;
import java.util.List;

/**
 *
 * @author Aniket
 */
@Local
public interface mybeanLocal {
    
    public List<Mydata> getAlldata();
    
    public String addmydata(String fname,String address,String email,String password);
    
    public Mydata searchdata(int id);
    
    public String updatedata(int id,String fname,String address,String email,String password);
    
    public String removedata(int id);
    
}
