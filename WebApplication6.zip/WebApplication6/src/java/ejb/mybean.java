/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package ejb;

import entity.Mydata;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Aniket
 */
@Stateless
public class mybean implements mybeanLocal {

    @PersistenceContext(unitName = "WebApplication6PU")
    private EntityManager em;


    public void persist(Object object) {
        em.persist(object);
    }


    @Override
    public List<Mydata> getAlldata() {
        List<Mydata> mydata=em.createNamedQuery("Mydata.findAll").getResultList();
        return mydata;
    }

    @Override
    public String addmydata(String fname, String address, String email, String password) {
        Mydata mydata=new Mydata();
        mydata.setFname(fname);
        mydata.setAddress(address);
        mydata.setEmail(email);
        mydata.setPassword(password);
        em.persist(mydata);
        return "inserted";
    }

    @Override
    public String removedata(int id) {
        Mydata mydata=em.find(Mydata.class, id);
        em.remove(mydata);
        return "Deleted";
    }

    @Override
    public Mydata searchdata(int id) {
        Mydata mydata=em.find(Mydata.class, id);
        return mydata;
    }

    @Override
    public String updatedata(int id, String fname, String address, String email, String password) {
        Mydata mydata=em.find(Mydata.class, id);
        mydata.setFname(fname);
        mydata.setAddress(address);
        mydata.setEmail(email);
        mydata.setPassword(password);
        em.persist(mydata);
        return "Updated";
    }

}
