/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package bean;

import ejb.mybeanLocal;
import entity.Mydata;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;

/**
 *
 * @author Aniket
 */
@Named(value = "newmanagebean")
@SessionScoped
public class newmanagebean implements Serializable {

    public mybeanLocal getSb() {
        return sb;
    }

    public void setSb(mybeanLocal sb) {
        this.sb = sb;
    }

    @EJB
    private mybeanLocal sb;
    
    int id;
    String fname,address,email,password;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Creates a new instance of newmanagebean
     */
    public newmanagebean() {
    }
    
    
    public List<Mydata> getAlldata()
    {
        return sb.getAlldata();
    }
    
    public String addmydata() {
        try {
            sb.addmydata(fname, address, email, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
        fname="";
        address="";
        email="";
        password="";
        return "index.jsf";
    }
    public void removedata(int id) {
        sb.removedata(id);
    }
    
    public String searchdata(int mid) {
        Mydata mydata=sb.searchdata(mid);
        id=mydata.getId();
        fname=mydata.getFname();
        address=mydata.getAddress();
        email=mydata.getEmail();
        password=mydata.getPassword();
        return "updatedata.jsf";
    }
    
    public String updatedata()
    {
        try {
            sb.updatedata(id, fname, address, email, password);
        } catch (Exception e) {
        }
        return "index.jsf";
    }
}
